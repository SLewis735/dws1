alert("It's OK to be a Quitter!");

alert("What is the cost of smoking?");

var packs = prompt("How many packs of cigarettes do you smoke a day?");
var days = prompt("How many days a week do you smoke?");
var years = prompt("How many years have you smoke?");
cost = 5.51
society = 18.01
total = packs * days * years * cost;
grand = packs * days * years * society;
alert("The average retail price of a pack of cigarettes in America is $5.51.");
alert("But the real price of a pack of cigarettes to society and to the state's economy is $18.05 per pack.");
var smoking = "This is the average amount you spend on cigarettes in your lifetime is " + total;
var economy = "Your contribution to society and to the state's economy for a lifetime of smoking is " + grand;
vacation = 1000
alert(smoking);
alert(economy);
alert("The real cost of smoking is your health and life.");
alert("Are you ready to be a Quitter?");



